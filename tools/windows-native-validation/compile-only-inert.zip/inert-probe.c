/* Compile-only controlled test DLL. No entrypoint, imports or constructors.
 * Exact official MSVC recipe is documented in BUILD-INERT.md. Not yet compiled. */
unsigned long keld_probe_marker(void) { return 0x4b454c44UL; }
