"""Read-only structural checks for the compile-only, unsigned inert x64 DLL.
Not signature, loader, runtime or containment evidence. Never executes input.
"""
import argparse,hashlib,json,struct
from pathlib import Path
MAX=1024*1024

def inspect(data):
    def require(v,message):
        if not v:raise ValueError(message)
    def u16(o):require(0<=o<=len(data)-2,'u16 extent');return struct.unpack_from('<H',data,o)[0]
    def u32(o):require(0<=o<=len(data)-4,'u32 extent');return struct.unpack_from('<I',data,o)[0]
    require(0<len(data)<=MAX and data[:2]==b'MZ','DOS/size')
    pe=u32(0x3c);require(64<=pe<=len(data)-24 and data[pe:pe+4]==b'PE\0\0','PE signature')
    require(u16(pe+4)==0x8664,'AMD64');n=u16(pe+6);require(1<=n<=32,'section count')
    require(u16(pe+22)&0x2002==0x2002,'executable DLL characteristic')
    opt=pe+24;size=u16(pe+20);require(size>=240 and opt+size<=len(data),'optional header extent')
    require(u16(opt)==0x20b,'PE32+');require(u32(opt+16)==0,'no entrypoint')
    require(16<=u32(opt+108)<=(size-112)//8,'directory count')
    require(u16(opt+70)&0x160==0x160,'ASLR/NX/high-entropy flags')
    headers=u32(opt+60);require(opt+size+n*40<=headers<=len(data),'headers extent')
    sections=[]
    for i in range(n):
        off=opt+size+i*40;vs=u32(off+8);va=u32(off+12);rs=u32(off+16);raw=u32(off+20);flags=u32(off+36)
        require(va>0 and va+max(vs,rs)<=0xffffffff,'section virtual extent')
        require(rs==0 or (raw>=headers and raw+rs<=len(data)),'section raw extent')
        for a,b,c,d,_ in sections:
            require(va+max(vs,rs)<=a or a+b<=va,'virtual overlap')
            require(rs==0 or d==0 or raw+rs<=c or c+d<=raw,'raw overlap')
        sections.append((va,max(vs,rs),raw,rs,flags))
    def offset(rva,length=1):
        matches=[(va,raw,rs) for va,_,raw,rs,_ in sections if va<=rva and rva+length<=va+rs]
        require(len(matches)==1,'RVA raw mapping');va,raw,_=matches[0];return raw+rva-va
    def directory(i):return u32(opt+112+i*8),u32(opt+116+i*8)
    for i in [1,4,9,11,12,13,14]:require(directory(i)==(0,0),'forbidden imports/signature/TLS/CLR directory')
    er,es=directory(0);require(er and es>=40,'export directory');e=offset(er,es)
    require(u32(e+20)==1 and u32(e+24)==1,'one export')
    def string(rva,limit=128):
        o=offset(rva);buf=bytearray()
        for i in range(limit):
            c=data[offset(rva+i)]
            if c==0:return bytes(buf).decode('ascii')
            buf.append(c)
        raise ValueError('unterminated export string')
    require(string(u32(e+12))=='keld-inert-probe.dll','fixed image name')
    fn=u32(offset(u32(e+28),4));name=u32(offset(u32(e+32),4));ordinal=u16(offset(u32(e+36),2))
    require(ordinal==0 and string(name)=='keld_probe_marker','fixed export')
    require(not er<=fn<er+es,'forwarder forbidden')
    offset(fn)
    require(any(va<=fn<va+rs and flags&0x20000000 and not flags&0x80000000 for va,_,_,rs,flags in sections),'export executable section')
    return {'schema':'keld.inert-pe-structure/v1','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'machine':'AMD64','entrypoint':0,'export':'keld_probe_marker','scope':'structure only, not load/qualification'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('dll',type=Path);a=p.parse_args()
    with a.dll.open('rb') as f:data=f.read(MAX+1)
    print(json.dumps(inspect(data),sort_keys=True))
