# Compile-only inert fixture recipe

Scope: build an unsigned, inert test DLL only. No load/execution, signing, trust,
ACL, profile, token/permission, installed-file change or final-app source change.
Execute ONLY through the existing qualified NativeRun/compiler family owner, once
this exact source/recipe/checker is reviewed and native tool identities match.
No retry until prior family retirement is observed. Preserve every failed output.

Inputs: exact `inert-probe.c` and `check_inert_pe.py` hashes in MANIFEST.json.
Official existing x64 MSVC cl.exe/link.exe only, same qualified VC/SDK environment;
not PATH-selected or downloaded executables. Fresh D:/KeldBuild owned output dir
must not exist; create once through approved test staging, no overwrite/cleanup.
Use argument arrays, not shell substitution. Absolute paths replace ROOT below.

1. CWD ROOT, bounded compiler-family execution:
   CL_EXE /nologo /c /O1 /GS /Zl /FoROOT/inert-probe.obj ROOT/inert-probe.c
2. Only if cl exit0 and family retirement proved:
   LINK_EXE /NOLOGO /DLL /NOENTRY /NODEFAULTLIB /INCREMENTAL:NO /MACHINE:X64
     /EXPORT:keld_probe_marker /DYNAMICBASE /NXCOMPAT /HIGHENTROPYVA
     /OUT:ROOT/keld-inert-probe.dll /IMPLIB:ROOT/keld-inert-probe.lib
     ROOT/inert-probe.obj
3. Only if link exit0 and family retirement proved:
   PINNED_PYTHON ROOT/check_inert_pe.py ROOT/keld-inert-probe.dll

Each flag/path is one argv entry (`/Fo` and `/OUT:` remain joined to their paths).
No `/GS-`, `/DEBUG`, library search override, custom DLL entrypoint, compiler hooks,
extra objects or libraries. Actual cl/link versions, inputs/output digests and
family receipts must be saved. Header check is read-only and prints digest,
size, AMD64/entry/export structural facts, never "valid runtime" or qualification.
The six synthetic parser tests are not a real native image result.

Expected structural predicates: executable AMD64 PE32+ DLL; zero entrypoint;
ASLR/NX/high-entropy flags; no imports/IAT/delay/bound imports, TLS, CLR or signature
directory; one non-forwarded fixed export in executable, non-writable raw section;
closed extents/no overlapping sections; fixed DLL export name. If any fail, stop
and inspect actual image/compiler outputs without relaxing checks by assumption.

Before ANY later load: independent actual PE review, same-source/controller
identity pin selection, fixed workspace materialization/ungranted member, native
positive-control review and any applicable security provisioning approval remain.
Native compile does not authorize loading this DLL or changing None build pins.
