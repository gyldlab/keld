"""One test-only Bun invocation, always called inside existing NativeRun Job."""
import json,os,pathlib,subprocess,sys

def main():
    root=pathlib.Path(__file__).absolute().parent
    if len(sys.argv)!=5:raise ValueError('case, Bun, parser, fresh work required')
    case,bun,parser,work=sys.argv[1:];work=pathlib.Path(work)
    env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','SYSTEMDRIVE'}}
    home=work/'empty-home';temp=work/'temp';home.mkdir();temp.mkdir()
    for name in ['bunfig.toml','.bunfig.toml']:(home/name).write_text('# empty test configuration\n')
    (home/'tsconfig.json').write_text('{"compilerOptions":{}}\n')
    env.update(HOME=str(home),USERPROFILE=str(home),APPDATA=str(home),LOCALAPPDATA=str(home),TEMP=str(temp),TMP=str(temp),NO_COLOR='1',BUN_INSTALL_CACHE_DIR=str(work/'empty-cache'))
    args=[bun,'--no-install','--no-env-file','--config='+str(home/'bunfig.toml'),'--tsconfig-override',str(home/'tsconfig.json'),str(root/'case.ts'),case,parser]
    with (work/'bun.stdout').open('xb') as out,(work/'bun.stderr').open('xb') as err:
        process=subprocess.Popen(args,cwd=work,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
        (work/'process.json').write_text(json.dumps({'pid':process.pid,'state':'running under existing outer Job'}))
        # No root-only kill/retry: on timeout the outer Job owns family retirement.
        code=process.wait(timeout=150)
    with (work/'bun.stdout').open('rb') as stream:raw=stream.read(1024*1024+1)
    if len(raw)>1024*1024:raise ValueError('case output bound')
    receipts=[]
    for line in raw.decode('utf-8').splitlines():
        try:value=json.loads(line)
        except json.JSONDecodeError:continue
        if isinstance(value,dict):receipts.append(value)
    if code:raise ValueError('Bun case failed')
    print(json.dumps({'case':case,'exit':code,'receipts':receipts,'state':'inner returned; outer retirement required'}))
    return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception:
        print('SEMANTIC_CASE_INCOMPLETE: preserve case logs; no retry',file=sys.stderr);raise SystemExit(2)
