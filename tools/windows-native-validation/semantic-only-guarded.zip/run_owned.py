"""Standalone semantics only; existing pinned NativeRun owns every process family."""
import argparse,hashlib,importlib.util,json,os,pathlib,sys
from types import SimpleNamespace
BUN='cb1d8e6564e655e49d30cead359750a1cbbd12f42651caa4b62244d7bd93c244'
PARSER='f9ecfbdc93753d2c972d66a8d0d75f5bd737fd4a5f88b422d9091ea282bcb2c7'
OWNER={'run_native.py':'e9ff0a06af697f9663c2b878820c3853fd78104e94f3aef691a630f8251df416','negative_control.py':'35e8fc4dccf3de0fc12415443e6331a6f038a14eac697c0cce06f59958b71d96'}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(path,expected=None):
    path=pathlib.Path(path)
    if not path.is_absolute():raise ValueError('absolute input required')
    for p in [path,*path.parents]:
        st=p.lstat()
        if p.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:raise ValueError('alias refused')
    with path.open('rb') as f:data=f.read(64*1024*1024+1)
    if len(data)>64*1024*1024 or (expected and digest(data)!=expected):raise ValueError('input identity')
    return data

def check_image(path,expected):
    # Executables use the existing256MiB image ceiling, not source-file limits.
    path=pathlib.Path(path)
    if not path.is_absolute():raise ValueError('absolute image required')
    for p in [path,*path.parents]:
        st=p.lstat()
        if p.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:raise ValueError('image alias')
    total=0;hasher=hashlib.sha256()
    with path.open('rb') as stream:
        while True:
            chunk=stream.read(1024*1024)
            if not chunk:break
            total+=len(chunk)
            if total>256*1024*1024:raise ValueError('image bound')
            hasher.update(chunk)
    if hasher.hexdigest()!=expected:raise ValueError('image identity')
    return total

def main():
    ap=argparse.ArgumentParser()
    for name in ['owner-root','guard','guard-sha256','bun','typescript-root','parser','evidence']:
        ap.add_argument('--'+name,required=True)
    a=ap.parse_args()
    if os.name!='nt':raise ValueError('Windows only')
    root=pathlib.Path(__file__).absolute().parent
    manifest=json.loads(read(root/'bundle-manifest.json'))
    for name,sha in manifest.items():
        if pathlib.PurePosixPath(name).is_absolute() or '..' in pathlib.PurePosixPath(name).parts or '\\' in name:raise ValueError('closed relative bundle')
        read(root/name,sha)
    bun=pathlib.Path(a.bun);parser=pathlib.Path(a.parser);ts=pathlib.Path(a.typescript_root);owner=pathlib.Path(a.owner_root);evidence=pathlib.Path(a.evidence)
    image_sizes={"bun":check_image(bun,BUN),"parser":check_image(parser,PARSER),"guard":check_image(pathlib.Path(a.guard),a.guard_sha256)}
    for name,sha in OWNER.items():read(owner/name,sha)
    if not evidence.is_absolute() or evidence.drive.lower()!='d:' or evidence.exists():raise ValueError('fresh D evidence required')
    for p in [evidence.parent,*evidence.parent.parents]:
        st=p.lstat()
        if p.is_symlink() or getattr(st,'st_file_attributes',0)&0x400:raise ValueError('evidence alias')
    tsmanifest=json.loads(read(root/'typescript-files.json'))
    for name,sha in tsmanifest.items():
        if pathlib.PurePosixPath(name).is_absolute() or '..' in pathlib.PurePosixPath(name).parts:raise ValueError('tool closure path')
        read(ts/pathlib.PurePosixPath(name),sha)
    package=json.loads(read(ts/'package.json'))
    if package.get('name')!='typescript' or package.get('version')!='7.0.2':raise ValueError('TS pin')
    # Load only already-installed exact process owner. No mutation entrypoint called.
    sys.path.insert(0,str(owner));spec=importlib.util.spec_from_file_location('semantic_existing_owner',owner/'run_native.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    args=SimpleNamespace(repo=str(root),evidence_dir=str(evidence),cargo=str(bun),positive_test_exe=a.guard)
    run=module.NativeRun(args)
    check_image(run.guard,a.guard_sha256)
    (evidence/'verified-image-sizes.json').write_text(json.dumps(image_sizes))
    # Private new workspace; product/compiler source is never edited.
    workspace=evidence/'semantic-input';workspace.mkdir()
    for name in manifest:
        if name.endswith('.ts') or name.startswith('fixture/') or name in ['run_case.py','cases.json']:
            raw=read(root/name,manifest[name])
            if name=='closed-app.ts':
                text=raw.decode()
                for export,relative in [('ast','dist/ast/index.js'),('async','dist/api/async/api.js'),('fs','dist/api/fs.js')]:
                    marker='"typescript/unstable/'+export+'"'
                    if text.count(marker)!=1:raise ValueError('exact fixture import seam')
                    text=text.replace(marker,json.dumps((ts/relative).as_uri()))
                raw=text.encode()
            destination=workspace/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
    run.repo=workspace
    cases=json.loads(read(root/'cases.json'));results=[]
    if not isinstance(cases,list) or len(cases)!=len(set(cases)) or not all(isinstance(c,str) and c and c.replace('-','').isalnum() for c in cases):raise ValueError('closed cases')
    for case in cases:
        if not run.family_verified:raise ValueError('prior family incomplete')
        work=evidence/case;work.mkdir()
        code,out,_=run.guarded(sys.executable,[str(workspace/'run_case.py'),case,str(bun),str(parser),str(work)],case,180)
        if code:raise ValueError('case failed; no retry')
        records=[json.loads(line) for line in out.splitlines() if line.startswith('{')]
        if len(records)!=1 or records[0].get('case')!=case or records[0].get('exit')!=0:raise ValueError('case receipt missing')
        receipts=records[0].get('receipts')
        if not isinstance(receipts,list) or len(receipts)!=1 or receipts[0].get('schema')!='keld.scaffold-semantic-case/v1' or receipts[0].get('case')!=case or receipts[0].get('expectedResultObserved') is not True:raise ValueError('semantic expected outcome missing')
        expected_count=32 if case=='renderer-negatives' else None
        if expected_count is not None and receipts[0].get('refusalCount')!=expected_count:raise ValueError('renderer negative census incomplete')
        results.append({'case':case,'family_retired':True,'inner':records[0]})
        (evidence/'cases-retired.json').write_text(json.dumps(results,indent=2))
    print(json.dumps({'semantic_cases_retired':len(results),'scope':'compiler/renderer semantics only; not archive/install/runtime qualification'}))
if __name__=='__main__':
    try:main()
    except BaseException:
        print('SEMANTIC_RUN_STOPPED: preserve evidence; no retry/cleanup',file=sys.stderr);raise
