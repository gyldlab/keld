// Test-only isolated compiler/renderer cases. Never execute generated application.
import { admitClosedApp, bundleCapturedApp } from "./closed-app.ts";
import { admitStaticRenderer } from "./static-renderer.ts";
import { rendererNegativeCases } from "./renderer-fixtures.ts";
const bytes = (text: string) => new TextEncoder().encode(text);
let refusalCount: number | undefined;
const [id, tsgo] = process.argv.slice(2);
if (process.argv.length !== 4 || !id || !tsgo) throw new Error("Expected case and retained absolute tsgo");
const parser = { tsserverPath: tsgo, virtualRoot: process.cwd().replaceAll("\\", "/") + "/virtual" };
const app = (text: string, entry = "src/main.ts", extras: [string,string][] = []) => new Map([
 [entry, bytes(text)], ...extras.map(([name, source]) => [name, bytes(source)] as [string,Uint8Array]),
]);
async function refuses(action: () => Promise<unknown>, message: string) {
 let rejected = false;
 try { await action(); } catch (error) {
  if (!(error instanceof Error) || !error.message.includes(message)) throw error;
  rejected = true;
 }
 if (!rejected) throw new Error("Expected refusal absent");
}
const negatives: Record<string,[string,string]> = {
 "missing-type": ['import type { Missing } from "./absent.ts"; export const x = 1;', "Import is absent"],
 "dynamic": ['await import("./other.ts");', "Dynamic imports"],
 "bare": ['import "node:fs";', "Only explicit relative"],
 "escape": ['import "../../outside.ts";', "Import escapes"],
 "malformed": ['const x: = ;', "Malformed captured"],
 "wrong-transport-directory": ['import "../kipc-transport.ts";', "Import is absent"],
};
if (id === "scaffold") {
 const modules = app(await Bun.file(new URL("./fixture/main.ts", import.meta.url)).text(), "src/main.ts", [
  ["src/echo.generated.ts", await Bun.file(new URL("./fixture/echo.generated.ts", import.meta.url)).text()],
 ]);
 const output = new TextDecoder().decode(await bundleCapturedApp(modules, parser, "src/main.ts"));
 if (!output.includes("./kipc-transport.js") || output.includes("./kipc-transport.ts") || output.includes("echo.generated.ts")) throw new Error("Unexpected compiled scaffold references");
 if (!output.includes("import.meta.main")) throw new Error("Entry main guard lost");
} else if (id === "types") {
 const output = new TextDecoder().decode(await bundleCapturedApp(app('import type { T } from "./types.ts"; export type { T } from "./types.ts"; const x: T = { n: 1 }; export { x };', "src/main.ts", [["src/types.ts", "export interface T { n: number }"]]), parser, "src/main.ts"));
 if (output.includes("types.ts") || output.includes("interface T")) throw new Error("Type-only edge leaked");
} else if (id === "legacy") {
 await bundleCapturedApp(app('export const x = 1;', "main.js"), parser, "main.js");
} else if (id === "js-ts-alias") {
 await refuses(() => admitClosedApp(app('import "./kipc-transport.ts";', "main.js"), parser, "main.js"), "Import is absent");
} else if (id === "reserved-case") {
 await refuses(() => admitClosedApp(app('export const x=1;', "src/main.ts", [["src/KIPC-TRANSPORT.TS", "export const x=2;"]]), parser, "src/main.ts"), "reserves generated transport");
} else if (id === "missing-entry") {
 await refuses(() => admitClosedApp(app('export const x=1;'), parser, "absent.ts"), "declared captured entry");
} else if (Object.hasOwn(negatives, id)) {
 const [source, message] = negatives[id];
 await refuses(() => admitClosedApp(app(source), parser, "src/main.ts"), message);
} else if (id === "renderer-negatives") {
 if (rendererNegativeCases.length !== 30) throw new Error("Renderer negative census changed");
 let count = 0;
 for (const [html, expectedReason] of rendererNegativeCases) {
  let rejected = false;
  try { await admitStaticRenderer(bytes(html)); } catch (error) {
   if (!(error instanceof Error) || error.message !== expectedReason) throw error;
   rejected = true;
  }
  if (!rejected) throw new Error("Expected renderer refusal absent");
  count += 1;
 }
 let invalidUtf8 = false;
 try { await admitStaticRenderer(new Uint8Array([255])); } catch (error) {
  if (!(error instanceof TypeError)) throw error;
  invalidUtf8 = true;
 }
 if (!invalidUtf8) throw new Error("Expected UTF8 decoding TypeError absent");
 count += 1;
 let emptyRefused = false;
 try { await admitStaticRenderer(new Uint8Array()); } catch (error) {
  if (!(error instanceof Error) || error.message !== "Renderer size outside supported bounds") throw error;
  emptyRefused = true;
 }
 if (!emptyRefused) throw new Error("Expected empty renderer refusal absent");
 count += 1;
 refusalCount = count;
} else if (id === "renderer-scaffold") {
 const input = new Uint8Array(await Bun.file(new URL("./fixture/index.html", import.meta.url)).arrayBuffer());
 const output = await admitStaticRenderer(input);
 if (output.length !== input.length || output.some((byte,i) => byte !== input[i])) throw new Error("Renderer bytes changed");
} else {
 throw new Error("Unknown closed test case");
}
// This is case-only evidence. Runner must additionally verify parser process drain.
console.log(JSON.stringify({ schema: "keld.scaffold-semantic-case/v1", case: id, expectedResultObserved: true, ...(refusalCount === undefined ? {} : { refusalCount }) }));
