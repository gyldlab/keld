# Separate compiler/renderer semantics only

No Rust, outer transaction, installer, signing, policy, certificate, ACL or denied
source plan is included or imported. No repository files are edited. This bundle
is NOT authorization to publish or execute it. Parent coordinates that separately.

Actual native command after exact ZIP/guard/source verification:
python run_owned.py --owner-root D:/KeldBuild/caller-image-base-20261110 --guard
D:/KeldBuild/caller-native-final-retirement-20261110/immutable-positive-guard.exe
--guard-sha256 FRESH_VERIFIED_EXISTING_GUARD_SHA --bun
D:/KeldBuild/bun-1.4.4-qualified/extracted/bun-windows-x64/bun.exe
--typescript-root D:/KeldBuild/compiler-tooling-20261110/node_modules/typescript
--parser D:/KeldBuild/compiler-tooling-20261110/node_modules/@typescript/typescript-win32-x64/lib/tsc.exe
--evidence D:/KeldBuild/FRESH_SEMANTIC_EVIDENCE

The guard SHA is unresolved: do not guess it or call the process with a placeholder.
Existing owner source hashes are hardcoded; its negative_control definitions are
imported as required by that existing owner but no mutation function is called or
shipped. Parent must verify this is the established guard executable and not a
new arbitrary test image. NativeRun owns each family and quarantines uncertainty.
No root-only kill, retry, cleanup, installs, downloads or credentials.

Bun hash cb1d8e65 identifies the previously qualified1.4.4 binary; parserf9ecfbdc
identifies official TS7.0.2 tsc.exe. Fresh file comparisons required at run start.
416 public TS distribution files are hash-checked once; no Cargo cache copy occurs.
Only three exact test import strings are adapted to verified absolute TS files.
Product source remains unchanged; adapted source is test-only evidence.

14 cases, one fresh Bun process and at most one compiler admission per case.
Renderer-negatives must report32refusals. Genuine scaffold case compiles source,
never executes generated app; it is not Host/IPC/runtime or installed evidence.
All runs get config-free HOME/temp and explicit Bun config/tsconfig, no inherited
BUN_OPTIONS or app-link credentials. Parser child is inside existing outer Job.
Success is recorded only after expected case receipt + family retirement.

Tool/hash checks are test observations, not persistent namespace authority. No
native Rust/Bun semantic run has occurred from this bundle; four Python mocked
runner tests and Node helper/protocol tests passed locally.
