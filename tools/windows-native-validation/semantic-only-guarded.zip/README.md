# Isolated semantic tests only

Run each cases.json ID in a fresh owned process:
`PINNED_BUN case.ts CASE_ID ABSOLUTE_PINNED_TSGO`
Cwd must be absolute Windows owned test workspace, with pinned TypeScript 7.0.2
package closure available to closed-app.ts via existing qualified module layout.
No app output is executed. No source/repository runner, installer, signing,
controller, outer, Rust or permissions modules are imported.

Run renderer tests separately: `PINNED_BUN test static-renderer.test.ts`.
Run framing tests separately with pinned Bun: `PINNED_BUN protocol.test.mjs`.
Pure helper test alias.test.mjs also supports Node.

case.ts success receipt is emitted only after expected outcome and API disposal;
parent NativeRun owner MUST verify whole Job/parser retirement before recording
case pass. Retire on timeout/error; do not launch a second admission in same process.
Renderer suite includes original inert HTML preservation, exact canonical scaffold,
CSS mutation/url/import/expression, event/refresh/duplicate-attribute and rawtext/
marker/end-tag negatives. Source version captured in manifest.json.

Cloud executed Node framing/helper tests only. Native Bun/TS/renderer cases unrun.
