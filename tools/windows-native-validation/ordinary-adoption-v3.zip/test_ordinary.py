import json,unittest,copy
from pathlib import Path
import preview_ordinary as view
PLAN=json.loads(Path(__file__).with_name('ordinary-source-plan.json').read_text())
class Tests(unittest.TestCase):
 def test_closed_targets(self):
  self.assertEqual(set(PLAN),view.TARGETS);self.assertEqual(len(PLAN),14)
  self.assertTrue(all(p.startswith('crates/keld-cli/') or p in {'crates/keld-update/src/lib.rs','crates/keld-update/src/manifest.rs'} for p in PLAN))
 def test_known_sources(self):
  for path,entry in PLAN.items():
   if path.endswith(('local_images.rs','windows_compiler.rs','keld-update/src/lib.rs')):continue
   v=entry['variants'][0];b=v['operations'][0]['before'].encode() if v['before_sha256'] else None
   self.assertEqual(view.sha(b) if b is not None else None,v['before_sha256']);view.transform(b,v)
 def test_root_export_only(self):
  v=copy.deepcopy(PLAN['crates/keld-update/src/lib.rs']['variants'][0]);v['after_sha256']=None;b=b'// retained prefix\npub use manifest::{ManifestDecision, SelectedFull};\n// retained suffix\n'
  self.assertEqual(view.transform(b,v),b.replace(b';\n// retained suffix',b';\npub use manifest::verify_literal_release_signature;\n// retained suffix'))
 def test_missing_duplicate_refuse(self):
  v=PLAN['crates/keld-update/src/lib.rs']['variants'][0];anchor=v['operations'][0]['before'].encode()
  for b in [b'no anchor',anchor+anchor]:
   with self.assertRaises(ValueError):view.transform(b,v)
 def test_new_file_never_overwrites(self):
  v=PLAN['crates/keld-cli/src/build/windows_product.rs']['variants'][0]
  with self.assertRaises(ValueError):view.transform(b'existing',v)
 def test_afterhash_refuses(self):
  v=copy.deepcopy(PLAN['crates/keld-cli/src/build/windows_product.rs']['variants'][0]);v['after_sha256']='0'*64
  with self.assertRaises(ValueError):view.transform(None,v)
 def test_repeated_test_append_refuses(self):
  with self.assertRaisesRegex(ValueError,'already present'):view.transform(b'mod scaffold_source_tests',{'operations':[],'append_exact':'test','after_sha256':None})
if __name__=='__main__':unittest.main()
